# Signal generation logic
