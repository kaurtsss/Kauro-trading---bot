# Entry point (FastAPI heartbeat)
