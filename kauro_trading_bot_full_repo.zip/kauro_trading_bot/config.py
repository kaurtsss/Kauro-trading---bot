# Loads .env variables
