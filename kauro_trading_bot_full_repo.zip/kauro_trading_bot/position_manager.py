# Position management (open/close)
